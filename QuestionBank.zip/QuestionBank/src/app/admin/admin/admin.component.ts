import { Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router'
import { StudentService } from 'src/app/student.service';
import { AngularFireDatabase, AngularFireList } from '@angular/fire/database';


@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  constructor(public _eventService: StudentService,
    private _router: Router, private route: ActivatedRoute) { }
    
   lang= 'C'
   Languages =['C','C++','Java','PHP','DBMS','DS','CN','Apti']
Questions=[]
ngOnInit() 
{
  if(this.route.snapshot.params.id){
    console.log(this.route.snapshot.params.id)
  this.lang=JSON.stringify(this.route.snapshot.params.id)
    this.lang=this.lang.replace (/(^")|("$)/g, '')  
  }

  this._eventService.getQuestions(this.lang).subscribe(list => {
    this.Questions = list.map(item => {
    return {
    $key: item.key,
      
    ...item.payload.val()

    }
    })
    });
    console.log(this.Questions)
}
showDeletedMessage:Boolean


  onSearch(lang)
  {
    this._eventService.getQuestions(lang).subscribe(list => {
      this.Questions = list.map(item => {
      return {
      $key: item.key,
        
      ...item.payload.val()
  
      }
      })
      });
      console.log(this.Questions)
  }
  


  onDelete($key,lang) 
  {
      if (confirm('Warning : Are you sure to cancel this entry...?')) 
      {
      this._eventService.deleteQuestion($key,lang);

      }
  }
 

  editComment(s)
  {
    console.log(s)
    this._router.navigate(['editcomment/'+s.language+'/'+s.$key])
  }


}
