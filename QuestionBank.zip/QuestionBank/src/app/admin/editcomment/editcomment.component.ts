import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { AngularFireDatabase, AngularFireList } from '@angular/fire/database';
import { StudentService } from 'src/app/student.service';

@Component({
  selector: 'app-editcomment',
  templateUrl: './editcomment.component.html',
  styleUrls: ['./editcomment.component.css']
})
export class EditcommentComponent implements OnInit {

  constructor(private firebase: AngularFireDatabase,
    private _router: Router, private route: ActivatedRoute,private eventService:StudentService) { }

  Ans
  lang
  key
  showDeletedMessage=false
  Comments=[]

  ngOnInit(): void {

    

    this.lang=JSON.stringify(this.route.snapshot.params.lang)
    this.lang=this.lang.replace (/(^")|("$)/g, '')
    this.key=JSON.stringify(this.route.snapshot.params.id)
    this.key=this.key.replace (/(^")|("$)/g, '')
    console.log(this.key)

    this.firebase.object(this.lang+'/'+this.key).valueChanges().subscribe(val =>{ 
      console.log(val);
      this.Ans=val
      this.Ans.$key=this.key
      
    })

    this.eventService.getQuestions('Q'+this.key).subscribe(list => {
      this.Comments = list.map(item => {
      return {
      $key: item.key,
        
      ...item.payload.val()
  
      }

      })
      });

  }

  onDelete($key) 
  {
      if (confirm('Warning : Are you sure to delte this comment...?')) 
      {
      this.eventService.deleteQuestion($key,'Q'+this.key);

      }
  }

  editComment(s)
  {
    this._router.navigate(['ans/'+this.Ans.language+'/'+this.Ans.$key+'/'+s.$key]);

  }

  back()
  {
    console.log("Vk")
    this._router.navigate(['admin/'+this.Ans.language]);

  }
}
