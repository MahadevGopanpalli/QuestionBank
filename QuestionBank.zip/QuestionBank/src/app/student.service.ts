import { Injectable } from '@angular/core';
import { AngularFireDatabase, AngularFireList } from '@angular/fire/database';
import {AngularFirestore, AngularFirestoreCollection } from '@angular/fire/firestore';
import { Router ,NavigationExtras} from '@angular/router';
@Injectable({
  providedIn: 'root'
})
export class StudentService {

  constructor(private firebase: AngularFireDatabase,
    private _router: Router) { }
 
  Questions:AngularFireList<any>;

  object

  insert(detail)
  {
    this.firebase.list(detail.language).push(detail);
    alert("Thanks for adding question...")
    this._router.navigate(['/'])
  }

  insertComment(que,detail)
  {
    
  
    this.firebase.list('Q'+que.$key).push(detail);
    alert("Thanks for adding comment...")
    
  }

  updateComment(que,data)
  {
    this.firebase.list('Q'+que.$key).update(data.$key,
      {
        name: data.name,
        comment: data.comment,

      });
      alert("Updated Successfully...")

      this._router.navigate(['editcomment/'+que.language+'/'+que.$key]);
  }


  
getQuestions(lang)
  { console.log(lang)
    if(this.firebase.list(lang))
      {
        this.Questions=this.firebase.list(lang);
    
      return this.Questions.snapshotChanges();
      }

  }


  getDetails(lang,$key)
  {
    console.log('Vk')
    this.firebase.object(lang+'/'+$key).valueChanges().subscribe(val =>{ 
      console.log(val);
      this.object=val
    })
    return this.object
  }


  Update(edit)
  { 
    console.log(edit)
       
      this._router.navigate(['form/'+edit.language+'/'+edit.$key]); 
  }


  updateDetail(data)
  {
    this.firebase.list(data.language).update(data.$key,
      {
        name: data.name,
        language: data.language,
        question: data.question,
        answer: data.answer
      });
      alert("Updated Successfully...")

      this._router.navigate(['admin/'+data.language]);
  }



  deleteQuestion($key,lang) 
  {
    console.log(lang)
    this.firebase.list(lang).remove($key);
  }

 
}
