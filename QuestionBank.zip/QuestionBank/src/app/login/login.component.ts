import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth/auth.service';
import { getMaxListeners } from 'process';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginUserData={email:'',password:''}
  V=false
  constructor(private  authService:  AuthService,private _router:Router) { }

  ngOnInit() {
  }

  loginUser()
  {
   /* if(this.authService.login(this.loginUserData.email,this.loginUserData.password))
    {
      
    }
    else
      this.V=true
  }
*/
if(this.loginUserData.email=="dev19@gmail.com" && this.loginUserData.password=="Dev@19") {
  this._router.navigate(['/admin'])	
}
else{
this._router.navigate(['/login'])
this.V=true  
}
}}
