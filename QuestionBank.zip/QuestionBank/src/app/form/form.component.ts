import { Component, OnInit } from '@angular/core';
import {FormBuilder,FormGroup,Validators, FormControl, MinLengthValidator} from '@angular/forms'
import { AngularFireDatabase, AngularFireList } from '@angular/fire/database';

import { StudentService } from '../student.service'
import { Router, ActivatedRoute, ParamMap } from '@angular/router';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit {

  QuestionForm =  new FormGroup({
    $key: new FormControl(null),
    name: new FormControl('', Validators.required),
    language: new FormControl('',),
    question: new FormControl('', Validators.required),
    answer: new FormControl('')
  });

  constructor(public fbobj : FormBuilder,
    private eventService : StudentService,private firebase: AngularFireDatabase,
      private route: ActivatedRoute){
     
    }
    showSuccessMessage=false;
    submitted:boolean;
    lang
    key
    Ans
  ngOnInit()
  {
    this.lang=JSON.stringify(this.route.snapshot.params.id)
    this.lang=this.lang.replace (/(^")|("$)/g, '')
    

    if(!this.Languages.includes(this.lang))
    {
      this.lang=JSON.stringify(this.route.snapshot.params.lang)
    this.lang=this.lang.replace (/(^")|("$)/g, '')

    this.key=JSON.stringify(this.route.snapshot.params.id)
    this.key=this.key.replace (/(^")|("$)/g, '')

      this.firebase.object(this.lang+'/'+this.key).valueChanges().subscribe(val =>{ 
        this.Ans=val

        console.log(this.key)
        this.QuestionForm.setValue({
          $key:this.key,
          name: this.Ans.name,
          language: this.Ans.language,
          question: this.Ans.question,
          answer: this.Ans.answer
        });
      })
      console.log("Mahadev")
      
    }


    
    
   
  

  }
  
  Languages =['C','C++','Java','PHP','DBMS','DS','CN','Apti']

 
onSubmit(){ 
this.submitted=true;
  console.log(this.QuestionForm.value)
  let data = Object.assign({}, this.QuestionForm.value);
  
  if (this.QuestionForm.get('$key').value == null)
  {   delete data.$key;
     this.eventService.insert(data) 
  }     
    else 
    { 
    this.eventService.updateDetail(data)
    } 
}   

}
