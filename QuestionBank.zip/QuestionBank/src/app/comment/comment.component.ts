import { Component, OnInit, Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl, MinLengthValidator } from '@angular/forms'
import { StudentService } from '../student.service';
import { AngularFireDatabase } from '@angular/fire/database';


@Component({
  selector: 'app-comment',
  templateUrl: './comment.component.html',
  styleUrls: ['./comment.component.css']
})
export class CommentComponent implements OnInit {

  @Input() public Question;
  
  constructor(private eventService: StudentService,private firebase: AngularFireDatabase) { }


  CommentForm = new FormGroup({
    $key: new FormControl(null),
    name: new FormControl('', Validators.required),

    comment: new FormControl('', Validators.required),

  });

  comments=[]
  V=true
  com

  ngOnInit(): void {
    console.log(this.Question)

    this.eventService.getQuestions('Q'+this.Question.$key).subscribe(list => {
      this.comments = list.map(item => {
      return {
      $key: item.key,
        
      ...item.payload.val()
  
      }

      }
      
        ),this.V=false
      });

      if(this.Question.que)
      {
        console.log('Q'+this.Question.que+'/'+this.Question.$key)

        this.firebase.object('Q'+this.Question.$key+'/'+this.Question.que).valueChanges().subscribe(val =>{ 
          this.com=val
          console.log(this.com)
          this.CommentForm.setValue({
            $key:this.Question.que,
            name:this.com.name,
            comment:this.com.comment
          })
      })
  
    }
  }

 

  onSubmit() {
    let data = Object.assign({}, this.CommentForm.value);

    if (this.CommentForm.get('$key').value == null) {
      delete data.$key;
      this.eventService.insertComment(this.Question,data)
      this.CommentForm.reset()
   
    }
    else 
    { 
    this.eventService.updateComment(this.Question,data)
    } 
  

  }

}
