import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AngularFireModule } from '@angular/fire';
import { AngularFireDatabaseModule } from '@angular/fire/database';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormComponent } from './form/form.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ListComponent } from './list/list.component';
import { LoginComponent } from './login/login.component';
import { AdminComponent } from './admin/admin/admin.component';
import { AuthGuardService } from './auth/auth-guard.service';
import { UiComponent } from './ui/ui.component';
import "@angular/compiler";
import { AnsComponent } from './ans/ans.component';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import { RouterModule } from '@angular/router';
import { LoadingComponent } from './loading/loading.component';
import { CommentComponent } from './comment/comment.component';
import { EditcommentComponent } from './admin/editcomment/editcomment.component';


const config = {
  apiKey: "AIzaSyCPU9eO1TxmbkhB0-mZR8Kfp75haxzmRVM",
  authDomain: "mahadev-9ebe5.firebaseapp.com",
  databaseURL: "https://mahadev-9ebe5.firebaseio.com",
  projectId: "mahadev-9ebe5",
  storageBucket: "mahadev-9ebe5.appspot.com",
  messagingSenderId: "137240443060",
  appId: "1:137240443060:web:8ad9dd0cad0e4b3118ffe1"
};

@NgModule({
  declarations: [
    AppComponent,
    FormComponent,
    ListComponent,
    LoginComponent,
    AdminComponent,
    UiComponent,
    AnsComponent,
    LoadingComponent,
    CommentComponent,
    EditcommentComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    AngularFireModule.initializeApp(config),
    AngularFireDatabaseModule,
    FormsModule,
    ReactiveFormsModule,
    
    

    
  ],
  providers: [ {provide: LocationStrategy, useClass: HashLocationStrategy},],
  bootstrap: [AppComponent]
})
export class AppModule { }
