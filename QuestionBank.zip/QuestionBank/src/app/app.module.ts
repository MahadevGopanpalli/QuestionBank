import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AngularFireModule } from '@angular/fire';
import { AngularFireDatabaseModule } from '@angular/fire/database';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormComponent } from './form/form.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ListComponent } from './list/list.component';
import { LoginComponent } from './login/login.component';
import { AdminComponent } from './admin/admin/admin.component';
import { AuthGuardService } from './auth/auth-guard.service';
import { UiComponent } from './ui/ui.component';
import "@angular/compiler";
import { AnsComponent } from './ans/ans.component';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import { RouterModule } from '@angular/router';
import { LoadingComponent } from './loading/loading.component';
import { CommentComponent } from './comment/comment.component';
import { EditcommentComponent } from './admin/editcomment/editcomment.component';


const config = {
  //put here firebase api keys

@NgModule({
  declarations: [
    AppComponent,
    FormComponent,
    ListComponent,
    LoginComponent,
    AdminComponent,
    UiComponent,
    AnsComponent,
    LoadingComponent,
    CommentComponent,
    EditcommentComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    AngularFireModule.initializeApp(config),
    AngularFireDatabaseModule,
    FormsModule,
    ReactiveFormsModule,
    
    

    
  ],
  providers: [ {provide: LocationStrategy, useClass: HashLocationStrategy},],
  bootstrap: [AppComponent]
})
export class AppModule { }
