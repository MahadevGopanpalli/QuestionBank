import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { StudentService } from '../student.service';
import { AngularFireDatabase, AngularFireList } from '@angular/fire/database';


@Component({
  selector: 'app-ans',
  templateUrl: './ans.component.html',
  styleUrls: ['./ans.component.css']
})
export class AnsComponent implements OnInit {

  constructor( private firebase: AngularFireDatabase,
    private _router: Router, private route: ActivatedRoute) { }

    Vk=false
    V=true
lang
key
Ans
que
  ngOnInit(): void {

    if(this.route.snapshot.params.ques)
      { console.log(this.route.snapshot.params.ques)
        this.lang=JSON.stringify(this.route.snapshot.params.lang)
        this.lang=this.lang.replace (/(^")|("$)/g, '')
        this.key=JSON.stringify(this.route.snapshot.params.id)
        this.key=this.key.replace (/(^")|("$)/g, '')
        this.que=JSON.stringify(this.route.snapshot.params.ques)
        this.que=this.que.replace (/(^")|("$)/g, '')
        this.Vk=true;
        this.firebase.object(this.lang+'/'+this.key).valueChanges().subscribe(val =>{ 
          console.log(val);
          this.Ans=val
          this.Ans.$key=this.key
          this.Ans.que=this.que
          this.V=false})
        
      }
    else{
    this.lang=JSON.stringify(this.route.snapshot.params.lang)
    this.lang=this.lang.replace (/(^")|("$)/g, '')
    this.key=JSON.stringify(this.route.snapshot.params.id)
    this.key=this.key.replace (/(^")|("$)/g, '')
    console.log(this.key)

    this.firebase.object(this.lang+'/'+this.key).valueChanges().subscribe(val =>{ 
      console.log(val);
      this.Ans=val
      this.Ans.$key=this.key
      this.V=false})
      this.Vk=false
    }
    
  }

  speech = new SpeechSynthesisUtterance();
  /* JS comes here */
  synth=window.speechSynthesis

  onBack(lang) {
    if(this.synth.speaking)
        this.synth.cancel();
    this._router.navigate(['list/'+lang]); 
    
  }

  comments()
  {
    console.log(this.Vk)
    if(this.Vk)
      this.Vk=false
    else  
      this.Vk=true
  }

   
         textToAudio() {

            
            this.speech.lang = "en-US";
            
            this.speech.text = this.Ans.answer;
            this.speech.volume = 1;
            this.speech.rate = 0.7;
            this.speech.pitch = 2;
            if(this.synth.speaking)
              this.synth.cancel();
          else
            this.synth.speak(this.speech);
        }
}
