import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FormComponent } from './form/form.component';
import { AppComponent } from './app.component';
import { ListComponent } from './list/list.component';
import { LoginComponent } from './login/login.component';
import { AdminComponent } from './admin/admin/admin.component';
import { AuthService } from './auth/auth.service';
import { 
  AuthGuardService as AuthGuard 
} from './auth/auth-guard.service';
import { UiComponent } from './ui/ui.component';
import { AnsComponent } from './ans/ans.component';
import { EditcommentComponent } from './admin/editcomment/editcomment.component';

const routes: Routes = [
  {
    path: 'form/:id',
    component: FormComponent
  },{
    path: 'form/:lang/:id',
    component: FormComponent
  },

  
  {
    path:'',
    redirectTo: '/ui',
    pathMatch: 'full'
  },
  {
    path: 'list/:id',
    component: ListComponent
  }, 
   {
    path: 'ans/:id',
    component: AnsComponent
  },
  {
    path: 'ans/:lang/:id',
    component: AnsComponent
  },
  {
    path: 'ans/:lang/:id/:ques',
    component: AnsComponent
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'ui',
    component: UiComponent
  },
  {
    path: 'admin',
    component: AdminComponent,
    
  },
  {
    path: 'admin/:id',
    component: AdminComponent,
    
  },
  {
    path: 'editcomment/:lang/:id',
    component: EditcommentComponent,
    
  }
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes,{ useHash: true,scrollPositionRestoration:'top' })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
