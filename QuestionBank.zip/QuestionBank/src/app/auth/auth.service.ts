import { Injectable } from '@angular/core';
import { Router } from  "@angular/router";
import { auth } from  'firebase/app';
import { AngularFireAuth } from  "@angular/fire/auth";
import { User } from  'firebase';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { JwtHelperService } from '@auth0/angular-jwt';

@Injectable({
  providedIn: 'root'
})
export class AuthService  {

  user:  User;
  public loggedIn = false;
    constructor(public  afAuth:  AngularFireAuth, public  router:  Router) { 

      this.loggedIn = !!sessionStorage.getItem('user');

    }
 
    async login(email: string, password: string) {
      console.log(email)
      console.log(password)

      var result = await this.afAuth.signInWithEmailAndPassword(email, password)

      this.router.navigate(['/admin']);

  }

  public isAuthenticated(): boolean {
    
    return this.loggedIn
  }


 
}

