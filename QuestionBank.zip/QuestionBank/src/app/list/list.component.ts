import { Component, OnInit } from '@angular/core';
import {FormBuilder,FormGroup,Validators, FormControl, MinLengthValidator} from '@angular/forms'
import { StudentService } from '../student.service'
import { Router, ActivatedRoute, ParamMap } from '@angular/router';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {

  constructor(private _eventService: StudentService,
    private _router: Router,  private route: ActivatedRoute) { }
    
   lang
Questions=[]
V=true
ngOnInit() 
{    this.lang=JSON.stringify(this.route.snapshot.params.id)
  this.lang=this.lang.replace (/(^")|("$)/g, '')
  this._eventService.getQuestions(this.lang).subscribe(list => {
    this.Questions = list.map(item => {
    return {
    $key: item.key,
      
    ...item.payload.val()

    }
    }),this.V=false
    });
    
    console.log(this.lang)

}
showDeletedMessage:Boolean

onSearch(term,lang) {
  console.log(term)
  this._router.navigate(['ans/'+term+'/'+lang]); 
}
  



 
  
  }


